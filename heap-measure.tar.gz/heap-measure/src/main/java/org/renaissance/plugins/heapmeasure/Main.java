package org.renaissance.plugins.heapmeasure;

import java.lang.Runtime;
import java.lang.management.ManagementFactory;

import org.renaissance.Plugin;

public class Main implements Plugin,
    Plugin.AfterOperationSetUpListener,
    Plugin.BeforeOperationTearDownListener,
    Plugin.MeasurementResultPublisher {

  Runtime __runtime;

  long __heapSizeBefore;
  long __heapSizeAfter;

  private long heapSize() {
    return __runtime.totalMemory() - __runtime.freeMemory();
  }

  public Main() {
    __runtime = Runtime.getRuntime();
  }

  @Override
  public void afterOperationSetUp(String benchmark, int opIndex, boolean isLastOp) {
    __heapSizeBefore = heapSize();
  }

  @Override
  public void beforeOperationTearDown(String benchmark, int opIndex, long harnessDuration) {
    __heapSizeAfter = heapSize();
  }

  @Override
  public void onMeasurementResultsRequested(String benchmark, int opIndex, Plugin.MeasurementResultListener dispatcher) {
    dispatcher.onMeasurementResult(benchmark, "heap_size_after", __heapSizeAfter);
    dispatcher.onMeasurementResult(benchmark, "heap_size_before", __heapSizeBefore);
  }
}
